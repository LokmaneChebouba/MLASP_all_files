#!/bin/bash
#$ -S /bin/bash
#$ -M lchebouba@gmail.com
#$ -N similarities
. /etc/profile.d/modules.sh

#./gringo instance.lp encode.lp --const n=20 | clasp -n 0
# n= nombre fixé de protéines similaire.



module load clasp
module load gringo

cd ASP_Projet



gringo instance.lp my_solTest2.lp --const n=10 | clasp -n 0

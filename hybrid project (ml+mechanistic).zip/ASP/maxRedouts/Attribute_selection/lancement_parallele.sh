#!/bin/bash
#$ -S /bin/bash

#$ -pe mpich2 32
#$ -R y
#$ -M lchebouba@gmail.com
#$ -N similarities
. /etc/profile.d/modules.sh

#./gringo instance.lp encode.lp --const n=20 | clasp -n 0
# n= nombre fixé de protéines similaire.



#module load clasp
#module load gringo
module load clingo

cd Attribute_selection



#gringo instance_all.lp my_solTest2.lp --const n=10 | clasp -n 0 --parallel-mode=64
clingo -n 0 --const n=10 my_solTest2.lp instance_fin_pca.lp --parallel-mode 32

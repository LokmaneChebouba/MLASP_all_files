#!/bin/bash
#$ -S /bin/bash
#$ -M lchebouba@gmail.com
#$ -N similarities
. /etc/profile.d/modules.sh

#./gringo instance.lp encode.lp --const n=20 | clasp -n 0
# n= nombre fixé de protéines similaire.



module load clasp
module load gringo

cd my_sol



gringo instance30_60.lp my_solTest1.lp --const n=10 | clasp -n 0

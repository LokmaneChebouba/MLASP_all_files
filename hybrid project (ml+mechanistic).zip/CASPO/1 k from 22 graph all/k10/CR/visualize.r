library(CellNOptR)
cnolist = CNOlist(CNOdata("data_MIDAS_CR.csv"))
plot(cnolist)
